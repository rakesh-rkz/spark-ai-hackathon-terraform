// index.js
exports.handler = async (event) => {
  console.log("Hello from test Lambda!");
  return {
    statusCode: 200,
    body: JSON.stringify("Test successful"),
  };
};